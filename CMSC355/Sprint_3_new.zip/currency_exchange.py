#***********************************************************
# Currency Module
#
# Component: Task Layer - Currency Service
#***********************************************************
# Function:
#       Display the available currencies along with the exchange rate for the current currency to the others. 
#       When the currency is changed, then all prices on other screens will be displayed in the desiredCured currency
#***********************************************************
# Input:
#       Parameters - None
# Output:
#       Return - returnCode -> 0 if the currency was found, -1 otherwise (Note that the curCurrency variable will be changed)
#***********************************************************
# Author: Jack McGowan
# Version: 4/19/2023 CMSC 355
#***********************************************************

import config
import csv
import utility_layer

def changeCurrency():
    print("Current Currency: " + config.curCurrency[0]) # Display the current currency
#--------------------------------------------------------
# Open the file containing the available currencies and read them in to the rows variable
#--------------------------------------------------------
    with open(config.currencyFileName, 'r') as file:
        csvreader = csv.reader(file)
        rows = [] # Holds the list of currencies
        for row in csvreader:
            rows.append(row)
        rows.pop(0) # Remove the headers from the list
        n = len(rows) # Store the number of available currencies
#--------------------------------------------------------
# Display all of the available currencies along with the exchange rate
#--------------------------------------------------------
    for i in range(n):
        print(f"{i}. {rows[i][0]}   {config.curCurrency[2]}1 -> {rows[i][2]}{float(rows[i][1]) / float(config.curCurrency[1]):#.2f}")
    desiredCur = int(input("Your selection: ")) # Prompt user and store their input for which currency they wany
    returnCode = 0
#--------------------------------------------------------
# If the desiredCur is within the number of currencies then it exists and can be selected
# else, there is no currency at that index and call the errorHandler
#--------------------------------------------------------
    if desiredCur < len(rows):
        config.curCurrency = rows[desiredCur]
        print("Currency successfully changed")
    else:
        utility_layer.errorHandler('805')
        returnCode = -1
    print("Returning to main menu\n\n\n\n")
    return returnCode




