import hotel_search

def main():
    print("Testing call to hotel search and sorting by departure time")
    data = hotel_search.hotelSearch()
    print(f"Returned data: {data}\n")
    print("Testing call hotel search and sorting by price")
    data = hotel_search.hotelSearch()
    print(f"Returned data: {data}")
    print("Testing call to hotel module and choosing 0 to return to main menu")
    data = hotel_search.hotelSearch()
    print(f"Returned data: {data}")
    print("Testing call to hotel module and not choosing a hotel to return to main menu")
    data = hotel_search.hotelSearch()
    print(f"Returned data: {data}")

if __name__ == "__main__":
    main()